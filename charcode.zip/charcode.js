const [,, ...keywordArr] = process.argv

const [ key, cipher = 'Z' ] = keywordArr

const charCipher = cipher.charCodeAt(0)
const ciphered = []

for (let i = 0; i < key.length; i++) {
   const md5 = (key.charCodeAt(i) ^ charCipher) & charCipher
   ciphered.push(String.fromCharCode(md5))
}

console.log(ciphered)

const output = []
for (let i = 0; i < ciphered.length; i++) {
   const md5 = (key.charCodeAt(i))
   output.push(String.fromCharCode(md5))
}

console.log(output)